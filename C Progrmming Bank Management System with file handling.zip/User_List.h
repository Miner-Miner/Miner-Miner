#ifndef USER_LIST_H_INCLUDED
#define USER_LIST_H_INCLUDED
#include "Data.h"
#include "Limit_Input.h"

//view the list of user from record file

int userList(){
    char ch,buffer[BUFF_MAX],tmpName[100],tmpID[11];
    FILE *rec;
    rec = fopen("record/rec.dat","r");
    for(i=0;i<BUFF_MAX && fgets(buffer,BUFF_MAX,rec);i++){
        for( k=0,j=20;j<sizeof(buffer)&&buffer[j]!='\0';j++,k++){
            ch=buffer[j];
            tmpName[k]=ch;
        }
        tmpName[k]=0;
        for( k=0,j=4;j<14;j++,k++){
            ch=buffer[j];
            tmpID[k]=ch;
        }
        tmpID[k]='\0';
        for(k=0,j=4;j<sizeof(tmpName)&&tmpName[j]!=NULL;j++,k++){
            if(tmpName[j]!='<'){
                tmpName[k]=tmpName[j];
            }else{
                j=sizeof(tmpName);
            }
        }
        tmpName[k-1]='\0';
        if(i<10){
            printf("\n\t\t\t\t %d: Account Id: %s Name: %s",i+1,tmpID,tmpName);
        }else if(i<100){
            printf("\n\t\t\t\t%d: Account Id: %s Name: %s",i+1,tmpID,tmpName);
        }
    }
    printf("\n\n\t\t\t\tPress 1: Back to Main Menu\n\t\t\t\tPress 2: Exit");
    while(1){
        ch=getch();
        if(ch=='1'){
            clear();
            printf("\n\n\n\n\t\t\t\tReturning to Main Menu");
            loading(5);
            return 0;
        }else if(ch=='2'){
            clear();
            printf("\n\n\n\n\t\t\t\tExiting");
            loading(5);
            return 1;
        }
    }
}



#endif // USER_LIST_H_INCLUDED
