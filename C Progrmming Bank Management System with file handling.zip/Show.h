#ifndef SHOW_H_INCLUDED
#define SHOW_H_INCLUDED
#include "Data.h"
#include <stdio.h>

#define BUFF_SIZE 1024

/*
    show data from file that user wanted by searching line by line
*/
void show(int line){
    FILE *data;
    det detail;
    int i,j,k,temp;
    char buff[BUFF_SIZE],age[3],total[20];
    data = fopen("tmp/data.dat","r+");
    for (i=0; i<BUFF_SIZE&&fgets(buff,BUFF_SIZE,data)!=NULL ;i++){
        if(line==i){
            for(j=0,k=4;k<14;j++,k++){
                detail.account_id[j]=buff[k];
            }
            detail.account_id[j]='\0';
            for(j=0,k=24;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                detail.name[j]=buff[k];
            }
            detail.name[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                detail.date_of_birth[j]=buff[k];
            }
            detail.date_of_birth[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                age[j]=buff[k];
            }
            age[j]='\0';
            sscanf(age,"%d",&detail.age);
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                detail.national_id[j]=buff[k];
            }
            detail.national_id[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                detail.phone_number[j]=buff[k];
            }
            detail.phone_number[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                detail.address[j]=buff[k];
            }
            detail.address[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                detail.gmail[j]=buff[k];
            }
            detail.gmail[j]='\0';
            for(j=0,k+=10;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                detail.type_of_account=buff[k];
            }
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                total[j]=buff[k];
            }
            total[j]='\0';
            sscanf(total,"%lf",&detail.cash.total_amount);
            printf("\n\n\n\n\t\t\t\tAccount ID      : %s\n\t\t\t\tName            : %s\n\t\t\t\tDate of Birth   : %s\n\t\t\t\tAge             : %d\n\t\t\t\tCitizenship     : %s",detail.account_id,detail.name,detail.date_of_birth,detail.age,detail.national_id);
            printf("\n\t\t\t\tPhone Number    : %s\n\t\t\t\tAddress         : %s\n\t\t\t\tGmail           : %s\n\t\t\t\tType of account : %c->",detail.phone_number,detail.address,detail.gmail,detail.type_of_account);
            type(detail.type_of_account);
            printf("\n%\t\t\t\tTotal Amount    : %lf\n",detail.cash.total_amount);
        }
    }
}


#endif // SHOW_H_INCLUDED
