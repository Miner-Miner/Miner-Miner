#ifndef LOGIN_H_INCLUDED
#define LOGIN_H_INCLUDED
#include <stdio.h>
#include "Limit_Input.h"

typedef struct Login{
    char username[20];
    char password[20];
}login;

int login_page(){
    login l;
    FILE* file;
    int i,j,start,ending,result;
    char user[20],pass[20],dec_user[20],dec_pass[20],buffer[256],ch;
    printf("\n\n\n\t\t\t\tEnter Username\n\t\t\t\t");                                   //get username
    for ( i = 0; ( i < 20 ) && (( ch = getchar()) != EOF) &&( ch !='\n' ); ++i ){
        user[i] = ch;
    }
    user[i] = '\0';
    clear();
    printf("\n\n\n\t\t\t\tEnter Password\n\t\t\t\t");                                   //get password
    for ( i=0,j=0; i < 20 ; i++ ){
        ch = getch();
        if(ch == 8){
            clear();
            printf("\n\n\n\t\t\t\tEnter Password\n\t\t\t\t");
            for(j=0;j<i-1;j++){
                printf("*");
            }
            i-=2;
        }else if(ch==13){
            break;
        }else{
            printf("*");
            pass[i]=ch;
        }
    }
    pass[i] = '\0';
    clear();
    file = fopen("tmp/login.dat","r");                                                              //read username and password from file
    for ( i = 0; ( i < 20 ) && (( ch = fgetc(file)) != EOF) && ( ch !='\n' ) ; ++i ){
        l.username[i] = ch;
    }
    l.username[i]='\0';
    for ( i = 0; ( i < 20 ) && (( ch = fgetc(file)) != EOF) && ( ch !='\n' ) ; ++i ){
        l.password[i] = ch;
    }
    for (i=0;i<20;i++){                         //you can use this loop to decode
        if(l.username[i]=='<'){
            start = i+1;
        }else if(l.username[i]=='>'){
            ending = i;
        }
    }
    for(start,j=0;start<ending;start++,j++){
        dec_user[j]=l.username[start];
    }
    dec_user[j]='\0';                           //decode end here
    for (i=0;i<20;i++){
        if(l.password[i]=='<'){
            start = i+1;
        }else if(l.password[i]=='>'){
            ending = i;
        }
    }
    for(start,j=0;start<ending;start++,j++){
        dec_pass[j]=l.password[start];
    }
    dec_pass[j]='\0';
    if(strcmp(dec_user,user)==0 && strcmp(dec_pass,pass)==0){                                                   //check if username and password are the same
        printf("\n\n\n\t\t\t\tLogin Successful.");                                                              //if same login successful by returning 0
        loading(5);
        clear();
        return 0;
    }else{                                                                                                      //else login again
        printf("\n\n\n\t\t\t\tLogin again.");
        loading(5);
        login_page();
    }
}

int changeUserPass(){
    char ch,password[20];
    int i,j;
    FILE *file,*tempFile;
    int line,count = 0;
    char buffer[256];
    int trueFalse=login_page();
    login change;
    while(trueFalse==0){
        printf("\n\n\t\t\tPress 1: Change Username\n\t\t\tPress 2: Change Password\n\n\n");
        ch=getch();
        clear();
        if(ch=='1' || ch=='2')
            break;
    }
    if(ch=='1'){
        line=1;
        printf("\n\n\t\t\tEnter New Username\n\t\t\t");
        scanf("%[^\n]s",change.username);
        printf("\n\n\t\t\tUsername successfully changed.");
        clear();
    }else{
        line=2;
        while(trueFalse==0){
            while(trueFalse==0){
                printf("\n\n\t\t\tEnter New Password\n\t\t\t");
                for ( i=0,j=0; i < 20 ; i++ ){
                    ch = getch();
                    if(ch == 8){
                        clear();
                        printf("\n\n\t\t\tEnter New Password\n\t\t\t");
                        for(j=0;j<i-1;j++){
                            printf("*");
                        }
                        i-=2;
                    }else if(ch==13){
                        break;
                    }else{
                        printf("*");
                        change.password[i]=ch;
                    }
                }
                change.password[i]='\0';
                clear();
                break;
            }
            while(trueFalse==0){
                printf("\n\n\t\t\tEnter Password again\n\t\t\t");
                for ( i=0,j=0; i < 20 ; i++ ){
                    ch = getch();
                    if(ch == 8){
                        clear();
                        printf("\n\n\t\t\tEnter Password again\n\t\t\t");
                        for(j=0;j<i-1;j++){
                            printf("*");
                        }
                        i-=2;
                    }else if(ch==13){
                        break;
                    }else{
                        printf("*");
                        password[i]=ch;
                    }
                }
                password[i]='\0';
                clear();
                break;
            }
        if(strcmp(password,change.password)==0){
            printf("\n\n\t\t\tPassword successfully changed.");
            loading(5);
            break;
        }
        }
    }
    file = fopen("tmp/login.dat","r");
    tempFile = fopen("tmp/temp.dat","w+");
    while ((fgets(buffer, 256, file)) != NULL)
    {
        count++;
        if (count == line){
            if(line==1)
                fprintf(tempFile,"<%s>\n",change.username);
            else
                fprintf(tempFile,"<%s>",change.password);
        }
        else
            fputs(buffer, tempFile);
    }
    fclose(file);
    fclose(tempFile);
    file = fopen("tmp/login.dat","w+");
    tempFile = fopen("tmp/temp.dat","r");
    while ((fgets(buffer, 256, tempFile)) != NULL)
    {
        fputs(buffer, file);
    }
    fclose(file);
    fclose(tempFile);
    while(trueFalse==0){
        printf("\n\n\t\t\tPress 1: Go to Main Menu\n\t\t\t\Press 2: Exit\n\n\n");
        ch=getch();
        clear();
        if(ch=='1'){
            return 0;
        }
        else if(ch=='2'){
            printf("\n\n\t\t\tExiting");
            loading(5);
            return 1;
        }
    }
}

#endif // LOGIN_H_INCLUDED
