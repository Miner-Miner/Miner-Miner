#ifndef TRANSITION_H_INCLUDED
#define TRANSITION_H_INCLUDED
#include "Data.h"
#include "Limit_Input.h"

/*
    search account
    make transition
*/

int transition(){
    tran acc;
    Boolean tf=0;
    char ch,buff[BUFF_MAX],age[5],total[30],record[20],trf[22];
    int line=0,status=1;
    double cash=0.0;
    FILE *data,*temp,*rec,*transit;
    while(tf==0){
        printf("\n\n\n\n\t\t\t\tPress 1: Select account via Username\n\t\t\t\tPress 2: Select account via ID\n\n\n\n\n");
        ch=getch();
        if(ch=='1'||ch=='2'){
            line=shrDet(ch);
            break;
        }
    }
    printf("\n\t\t\t\tPress any to continue");
    ch=getch();
    clear();
    data = fopen("tmp/data.dat","r");
    temp = fopen("tmp/temp.dat","w+");
    for (i=0;i<BUFF_MAX && fgets(buff,BUFF_MAX,data);i++){
        if(i!=line){
            fputs(buff,temp);
        }else if(i==line){
            for(j=0,k=4;k<14;j++,k++){
                acc.account_id[j]=buff[k];
            }
            acc.account_id[j]='\0';
            for(j=0,k=24;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.name[j]=buff[k];
            }
            acc.name[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.date_of_birth[j]=buff[k];
            }
            acc.date_of_birth[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                age[j]=buff[k];
            }
            age[j]='\0';
            sscanf(age,"%d",&acc.age);
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.national_id[j]=buff[k];
            }
            acc.national_id[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.phone_number[j]=buff[k];
            }
            acc.phone_number[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.address[j]=buff[k];
            }
            acc.address[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.gmail[j]=buff[k];
            }
            acc.gmail[j]='\0';
            for(j=0,k+=10;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.type_of_account=buff[k];
            }
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                total[j]=buff[k];
            }
            total[j]='\0';
            sscanf(total,"%lf",&acc.cash.total_amount);
        }
    }
    strcat(&trf,"record/");
    strcat(&trf,acc.account_id);
    strcat(&trf,".dat\0");
    transit = fopen(trf,"a+");
    printf("\n\n\n\n\t\t\t\tPress 1: Withdraw from account\n\t\t\t\tPress 2: Deposit to account\n\t\t\t\tPress 3: Transition record\n\n\n\n\n\n");
    while(1){
        ch=getch();
        if(ch=='1'){
            clear();
            printf("\n\n\n\n\t\t\t\tWithdrawing from account.");
            loading(5);
            while(1){
                printf("\n\n\n\n\t\t\t\tYou have total of %lf$\n\t\t\t\tYou can withdraw %lf$\n\t\t\t\tHow much do you want to withdraw\n\t\t\t\t",acc.cash.total_amount,acc.cash.total_amount-10);
                cash=getFloatOnly();
                if(cash<=acc.cash.total_amount-10){
                    acc.cash.total_amount=acc.cash.total_amount-cash;
                    break;
                }else{
                    printf("You have to put at least 10$ in your account.");
                    loading(5);
                }
            }
            fprintf(transit,"<wit>%lf</wit>\n",cash);
            clear();
            break;
        }else if(ch=='2'){
            clear();
            printf("Depositing to account.");
            loading(5);
            printf("\n\n\n\n\t\t\t\tYou have total of %lf$\n\t\t\t\tHow much do you want to deposit\n\t\t\t\t",acc.cash.total_amount);
            cash=getFloatOnly();
            acc.cash.total_amount=cash+acc.cash.total_amount;
            fprintf(transit,"<dep>%lf</dep>\n",cash);
            clear();
            break;
        }else if(ch=='3'){
            clear();
            printf("\n\n\n");
            for(i=0;i<BUFF_MAX&&fgets(buff,BUFF_MAX,transit);i++){
                if(buff[1]=='d'){
                    for(j=0,k=5;k<BUFF_MAX&&buff[k]!='<';j++,k++){
                        record[j]=buff[k];
                    }
                    record[j]='\0';
                    printf("\n\t\t\t\tDeposit     : %s$",record);
                }else if(buff[1]=='w'){
                    for(j=0,k=5;k<BUFF_MAX&&buff[k]!='<';j++,k++){
                        record[j]=buff[k];
                    }
                    record[j]='\0';
                    printf("\n\t\t\t\tWithdrawal  : %s$",record);
                }
            }
            printf("\n\t\t\t\tTotal       : $%s$\n\t\t\t\tPress any to continue\n\n\n\n\n\n\n",total);
            ch=getch();
            clear();
            break;
        }
    }
    fclose(transit);
    fclose(data);
    fclose(temp);
    data = fopen("tmp/data.dat","w+");
    temp = fopen("tmp/temp.dat","r");
    for (i=1;i<BUFF_MAX && fgets(buff,BUFF_MAX,temp);i++){
            fputs(buff,data);
    }
    fprintf(data,"<id>%s</id> <nm>%s</nm> <dob>%s</dob> <ag>%d</ag> <nid>%s</nid> <ph>%s</ph> <add>%s</add> <gm>%s</gm> <ta>%c</ta> <tot>%lf</tot>\n",acc.account_id,acc.name,acc.date_of_birth,acc.age,acc.national_id,acc.phone_number,acc.address,acc.gmail,acc.type_of_account,acc.cash.total_amount);
    fclose(data);
    fclose(temp);
    printf("\n\n\n\n\t\t\t\tPress 1: Back to Main Menu\n\t\t\t\tPress 2: Exit");
    while(1){
        ch=getch();
        if(ch=='1'){
            clear();
            printf("\n\n\n\n\t\t\t\tReturning to Main Menu");
            loading(5);
            return 0;
        }else if(ch=='2'){
            clear();
            printf("\n\n\n\n\t\t\t\tExiting");
            loading(5);
            return 1;
        }
    }
}

#endif // TRANSITION_H_INCLUDED
