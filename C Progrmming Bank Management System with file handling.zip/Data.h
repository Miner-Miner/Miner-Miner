#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED
#include <stdio.h>
//Create custom type for other file use
int i=0,j=0,k=0;
typedef enum{TRUE,FALSE}Boolean;

typedef struct amount{
    double total_amount;
    double deposit_amount;
    double withdrawal_amount;
}amount;

typedef struct User{
    char account_id[11];
    char name[20];
    char date_of_birth[11];
    char current_date[11];
    char national_id[20];
    char address[100];
    char phone_number[15];
    char type_of_account;
    char gmail[40];
    int age;
    amount cash;
}add,upd,rem,det,tran;

void type(char tp){
    if(tp == '1'){
        printf("Saving");
    }else if(tp == '2'){
        printf("Current");
    }else if(tp == '3'){
        printf("Fixed1(for 1 year)");
    }else if(tp == '4'){
        printf("Fixed2(for 2 year)");
    }else if(tp == '5'){
        printf("Fixed3(for 3 year)");
    }
}

#endif // DATA_H_INCLUDED
