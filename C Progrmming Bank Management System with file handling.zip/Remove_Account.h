#ifndef REMOVE_ACCOUNT_H_INCLUDED
#define REMOVE_ACCOUNT_H_INCLUDED
/*
    get username or id from user
    search it in a file
    if exist get account ID and get line
        and remove file
*/
int removeAcc(){
    rem acc;
    Boolean tf=0;
    char ch,buff[BUFF_MAX],age[5],total[30],removefile[22];
    int line=0,status=1;
    FILE *data,*temp,*rec;
    while(tf==0){
        printf("\n\n\n\n\t\t\t\tPress 1: Remove account via Username\n\t\t\t\tPress 2: Remove account via ID\n\n\n\n\n");
        ch=getch();
        if(ch=='1'||ch=='2'){
            line=shrDet(ch);
            break;
        }
    }
    printf("\n\t\t\t\tPress any to continue");
    ch=getch();
    clear();
    data = fopen("tmp/data.dat","r");
    temp = fopen("tmp/temp.dat","w+");
    for (i;i<BUFF_MAX && fgets(buff,BUFF_MAX,data);i++){
        if(i!=line){
            fputs(buff,temp);
        }else if(i==line){
            for(j=0,k=4;k<14;j++,k++){
                acc.account_id[j]=buff[k];
            }
            acc.account_id[j]='\0';
        }
    }
    fclose(data);
    fclose(temp);
    strcat(&removefile,"record/");
    strcat(&removefile,acc.account_id);
    strcat(&removefile,".dat\0");
    data = fopen("tmp/data.dat","w+");
    temp = fopen("tmp/temp.dat","r");
    for (i=1;i<BUFF_MAX && fgets(buff,BUFF_MAX,temp);i++){
            fputs(buff,data);
    }
    fclose(data);
    fclose(temp);
    temp = fopen("tmp/temp.dat","w+");
    rec = fopen("record/rec.dat","r");
    for (i=0;i<BUFF_MAX && fgets(buff,BUFF_MAX,rec);i++){
        if(i!=line){
            fputs(buff,temp);
        }
    }
    fclose(rec);
    fclose(temp);
    temp = fopen("tmp/temp.dat","r");
    rec = fopen("record/rec.dat","w+");
    for (i=0;i<BUFF_MAX && fgets(buff,BUFF_MAX,temp);i++){
        fputs(buff,rec);
    }
    fclose(rec);
    fclose(temp);
    while(tf==0){
        status=remove(removefile);
        if(status==0){
            printf("\n\n\n\n\t\t\t\tRemoving");
            loading(5);
            break;
        }
    }
    printf("\n\n\n\n\t\t\t\tRemoved");
    printf("\n\t\t\t\tPress 1: Back to Main Menu\n\t\t\t\tPress 2: Exit");
    while(1){
        ch=getch();
        if(ch=='1'){
            clear();
            printf("\n\n\n\n\t\t\t\tReturning to Main Menu");
            loading(5);
            return 0;
        }else if(ch=='2'){
            clear();
            printf("\n\n\n\n\t\t\t\tExiting");
            loading(5);
            return 1;
        }
    }
}

#endif // REMOVE_ACCOUNT_H_INCLUDED
