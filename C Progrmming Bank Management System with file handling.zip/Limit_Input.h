#ifndef LIMIT_INPUT_H_INCLUDED
#define LIMIT_INPUT_H_INCLUDED
#include<stdio.h>
#include<math.h>

void clear(){
    system("cls");
}
//down three functions are limit input function
double getFloatOnly(){
    double num = 0.0;
    char ch;
    int i=0,j=0;
    do{
        ch=getch();
        if((ch>=48 && ch<=57) || ch=='.'){
            if(ch=='.' && i<1){
                i++;
            }else if(ch=='.' && i==1){
                num=num/pow(10,j)*10;
                break;
            }
            printf("%c",ch);
            if(i==1 && j==0){
            }else
                num=num*10+(ch-48);
            if(i==1){
                j++;
            }
        }
        if(ch==13){
            if(j>0)
                num=num/pow(10,j)*10;
            break;
        }
    }while(1);
    return num;
}

int getConditionalInt(int line){
    int ch,num=0;
    do{
        ch=getch();
        num=num+(ch-48);
        if(num<line+1)
            break;
    }while(1);
    return ch;
}

int getIntOnly(){
    int num = 0, ch;
    do{
        ch=getch();
        if(ch>=48 && ch<=57){
            printf("%c",ch);
            num=num*10+(ch-48);
        }
        if(ch==13)
            break;
    }while(1);
    return num;
}
//down here is delaying and loading functions
void delay(int sec){
    int i,j;
    for(i=0; i< sec; i++){
        j=i;
    }
}

void loading(int j){
    int i;
    for(i=0; i<j; i++){
        delay(200000000);
        printf(".");
    }
    clear();
}
//Greeing the user
void greet(){
    char greeting[30];
    int i;
    strcat(&greeting,"Welcome From Miner Bank\0");
    greeting[0]='W';
    printf("\n\n\n\n\t\t\t\t");
    for(i=0;i<strlen(greeting)&&greeting[i]!='\0';i++){
        printf("%c",greeting[i]);
        delay(100000000);
    }
    delay(500000000);
    clear();
}
#endif // LIMIT_INPUT_H_INCLUDED
