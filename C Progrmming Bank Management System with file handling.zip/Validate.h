#ifndef VALIDATE_H_INCLUDED
#define VALIDATE_H_INCLUDED
#include "Data.h"
//validate functions
int validate_dob(char *dob){
    char dd[2],mm[2],yyyy[4];
    int i,j,start,end,truefalse=0,date,month,year;
    if((dob[2]=='/' && dob[5]=='/') || (dob[1]=='/' && dob[3]=='/') || (dob[1]=='/' && dob[4]=='/') || (dob[2]=='/' && dob[4]=='/')){
        if(dob[2]=='/'&&dob[5]=='/'){
            dd[0] = dob[0];
            dd[1] = dob[1];
            sscanf(dd,"%02d",&date);
            mm[0] = dob[3];
            mm[1] = dob[4];
            sscanf(mm,"%02d",&month);
            yyyy[0] = dob[6];
            yyyy[1] = dob[7];
            yyyy[2] = dob[8];
            yyyy[3] = dob[9];
            sscanf(yyyy,"%04d",&year);
        }else if(dob[1]=='/'&&dob[3]=='/'){
            dd[0] = dob[0];
            sscanf(dd,"%02d",&date);
            mm[0] = dob[2];
            sscanf(mm,"%02d",&month);
            yyyy[0] = dob[4];
            yyyy[1] = dob[5];
            yyyy[2] = dob[6];
            yyyy[3] = dob[7];
            sscanf(yyyy,"%04d",&year);
        }else if(dob[1]=='/' && dob[4]=='/'){
            dd[0] = dob[0];
            sscanf(dd,"%02d",&date);
            mm[0] = dob[2];
            mm[1] = dob[3];
            sscanf(mm,"%02d",&month);
            yyyy[0] = dob[5];
            yyyy[1] = dob[6];
            yyyy[2] = dob[7];
            yyyy[3] = dob[8];
            sscanf(yyyy,"%04d",&year);
        }else{
            dd[0] = dob[0];
            dd[1] = dob[1];
            sscanf(dd,"%02d",&date);
            mm[0] = dob[3];
            sscanf(mm,"%02d",&month);
            yyyy[0] = dob[5];
            yyyy[1] = dob[6];
            yyyy[2] = dob[7];
            yyyy[3] = dob[8];
            sscanf(yyyy,"%04d",&year);
        }
        if(date<32){
            if(month<13){
                int is_leap=0;
                if(((year%4==0) && ((year%400==0) || (year%100!=0)))){
                    is_leap=1;
                }
                if( month==2){
                    if(date==30){
                        printf("\n\n\n\t\tThere is no February that has %u days.\n\t\tPlease Try again.",date);
                        loading(5);
                        clear();
                    }else if(date==29){
                        if(is_leap==0){
                            printf("\n\n\n\t\tThe year you born is not leap year.\n\t\tTherefore,this February does not have %u days.\n\t\tPlease Try again.",date);
                            loading(9);
                            clear();
                        }else{
                            return 1;
                        }
                    }else{
                        return 1;
                    }
                }else if( month==4 || month==6 || month==9 || month==11 ){
                    if (date==31){
                        if(month==4){
                            printf("\n\n\n\t\tThere is no April that has %u days.\n\t\tPlease Try again.",date);
                            loading(5);
                        }else if(month==6){
                            printf("\n\n\n\t\tThere is no June that has %u days.\n\t\tPlease Try again.",date);
                            loading(5);
                        }else if(month==9){
                            printf("\n\n\n\t\tThere is no September that has %u days.\n\t\tPlease Try again.",date);
                            loading(5);
                        }else{
                            printf("\n\n\n\t\tThere is no November that has %u days.\n\t\tPlease Try again.",date);
                            loading(5);
                        }
                    }else{
                        return 1;
                    }
                }else{
                    return 1;
                }
            }else{
                printf("\n\n\n\t\tThere is no year that has %u month.\n\t\tPlease Try again.",month);
                loading(5);
            }
        }else{
            printf("\n\n\n\t\tThere is no month that has %u days.\n\t\tPlease Try again.",date);
            }
            loading(5);
    }else{
        printf("\n\n\n\t\tYou have enter wrong date format.");
        loading(5);
    }
}

int validate_phone(char* ph){
    if(ph[0]=='+'){
        return 1;
    }else{
        printf("\n\n\t\tYou have enter wrong phone Format.\n\t\tPhone number should be start with country code\033[0;31m(+)\n\t\t");
        delay(1000000000000000);
        printf("Returning.");
        loading(6);
        return 0;
    }
}

int validate_gmail(char* gmail){
    if(gmail[0]<48 || gmail[0]>57){
        char *gm;
        gm = strstr(gmail,"@gmail.com");
        if(gmail!=NULL){
            return 1;
        }
        else{
            printf("\n\n\n\t\tYour Gmail format is wrong.\n\t\tHere is example gmail: example");
            printf("\033[0;31m");
            printf("@gmail.com\n\t\t");
            delay(100000000000000);
            printf("\033[0;37m");
            printf("Returning.");
            loading(6);
            return 0;
        }
    }else{
        printf("\n\n\n\t\tGmail does not start with number.\n\t\tReturning.");
        loading(6);
        return 0;
    }
}
#endif // VALIDATE_H_INCLUDED
