#ifndef CREATE_H_INCLUDED
#define CREATE_H_INCLUDED
#include<string.h>
#include "Data.h"
#include "Validate.h"

#define SIZE 256

char* generator(){
    int i,id_num;
    char *id = malloc(11);
    for(i=0;i<10;i++){                      //generate random and assign to account id;
        id_num = rand()%10;
        id[i] = id_num + '0';
    }
    id[10]='\0';
    return id;
}

int create_account(){                       //creating account function
    srand(time(NULL));
    add newUser;
    Boolean tf=0;
    FILE *data,*rec,*tranrec;
    char ch,dd[2],mm[2],yyyy[4];
    int i,j,date,month,year;
    char transition_record[22]={'r','e','c','o','r','d','/','0','1','2','3','4','5','6','7','8','9','.','d','a','t','\0'};
    while(tf==0){                                //check id already exist or not.If exist generate new id
        char* id=generator();
        for(i=0,j=7;i<10;i++,j++){                      //generate random and assign to account id;
            transition_record[j]=id[i];
            newUser.account_id[i]=id[i];
        }
        newUser.account_id[10]='\0';
        transition_record[22]='\0';
        if(access(transition_record,F_OK)==-1){
            break;
        }else{
            create_account();
        }
        free(id);
    }
    printf("\n\n\n\n\t\t\t\tCreating Account.");
    loading(5);
    while(tf==0){
        printf("\n\n\n\n\t\t\t\tEnter your name: ");                                        //Get name from user without restraint
        for ( i = 0; ( i < 20 ) && (( ch = getchar()) != EOF) &&( ch !='\n' ); ++i ){
            newUser.name[i] = ch;
        }
        newUser.name[i] = '\0';
        clear();
        break;
    }
    while(tf==0){
        printf("\n\n\n\n\t\t\t\tEnter your birth date(dd/mm/yyyy): ");                      //get Birthday
        scanf("%s",&newUser.date_of_birth);
        clear();
        tf = validate_dob(&newUser.date_of_birth);                                          //Call validate header and validate Birthday is real or not
    }
    tf=0;
    while(tf==0){
        printf("\n\n\n\n\t\t\t\tEnter your age: ");                                         //get age and check age
        newUser.age=getIntOnly();
        clear();
        if(newUser.age>17){
            break;
        }else{
            while(i){
            printf("\n\n\n\n\t\t\t\tAre you still minor?\n\t\t\t\tPress 0: Yes\n\t\t\t\tPress 1: No\n\n\n\n");
            ch = getch();
            clear();
                if(ch=='0'){
                    printf("\n\n\n\n\t\t\t\tYour are still minor.\n\t\t\t\tYou can't open account.\n\t\t\t\tExiting to Main Menu.");
                    loading(5);
                    return 0;
                }else if(ch=='1')
                    break;
            }
        }
    }
    printf("\n\n\n\n\t\t\t\tEnter your id: ");                                                  //get Citizenship
    scanf("%s",&newUser.national_id);
    clear();
    ch = getchar();
    while(tf==0){
        system("color 6F");                                                                     //get Ph.no and check it
        printf("\n\n\n\n\t\t\t\tEnter your Ph.no: ");
        newUser.phone_number[0]=getch();
        printf("%c",newUser.phone_number[0]);
        int x=getIntOnly();
        int length = snprintf( NULL, 0, "%d", x );
        char* str = malloc( length + 1 );
        snprintf( str, length + 1, "%d", x );
        for(i=0;i<sizeof(str);i++){
            newUser.phone_number[i+1]=str[i];
        }
        newUser.phone_number[i+2]='\0';
        free(str);
        clear();
        tf=validate_phone(&newUser.phone_number);
    }
    printf("\n\n\n\n\t\t\t\tEnter your address: ");                                         //get address
    scanf("%[^\n]s",&newUser.address);
    clear();
    tf=0;
    while(tf==0){                                                                           //get gmail
        system("color 6F");
        i=0;
        printf("\n\n\n\n\t\t\t\tEnter your Gmail: ");
        scanf("%s",&newUser.gmail);
        clear();
        tf=validate_gmail(&newUser.gmail);                                                  //check email format
    }
    tf=0;
    while(tf==0){                                                                           //get type of account
        printf("\n\n\n\n\t\t\t\tChoose your Type of Account.\n\t\t\t\tPress 1: Saving\n\t\t\t\tPress 2: Current\n\t\t\t\tPress 3: Fixed1(for 1 year)\n\t\t\t\tPress 4: Fixed2(for 2 year)\n\t\t\t\tPress 5: Fixed3(for 3 year)\n\n\n\n\n");
        ch=getch();
        clear();
        if(ch=='1'){
            newUser.type_of_account='1';
            break;
        }else if(ch=='2'){
            newUser.type_of_account='2';
            break;
        }else if(ch=='3'){
            newUser.type_of_account='3';
            break;
        }else if(ch=='4'){
            newUser.type_of_account='4';
            break;
        }else if(ch=='5'){
            newUser.type_of_account='5';
            break;
        }
    }
    printf("\n\n\n");
    while(tf==0){                                                                                   //get first deposit amount
        printf("\n\t\t\t\tEnter your first deposit Amount: ");
        newUser.cash.deposit_amount=getFloatOnly();
        newUser.cash.total_amount=newUser.cash.deposit_amount;
        clear();
        if(newUser.cash.deposit_amount>=10)
            break;
        else
            printf("\n\n\n\t\t\t\tYou have to deposit at least 10$");
    }
    printf("\n\n\n\n\t\t\t\tAccount successfully created.\n\t\t\t\tLoading.");
    loading(5);
    printf("\n\n\n\n\t\t\t\tAccount Id           : %s",newUser.account_id);                         //SHOW user result
    printf("\n\t\t\t\tName                 : %s",newUser.name);
    printf("\n\t\t\t\tDate of Birth        : %s",newUser.date_of_birth);
    printf("\n\t\t\t\tAge                  : %d",newUser.age);
    printf("\n\t\t\t\tID                   : %s",newUser.national_id);
    printf("\n\t\t\t\tPhone Number         : %s",newUser.phone_number);
    printf("\n\t\t\t\tAddress              : %s",newUser.address);
    printf("\n\t\t\t\tGmail                : %s",newUser.gmail);
    printf("\n\t\t\t\tType of Account      : %c->",newUser.type_of_account);
    type(newUser.type_of_account);
    printf("\n\t\t\t\tFirst Deposit Amount : %lf$",newUser.cash.deposit_amount);
    printf("\n\t\t\t\tTotla Amount         : %lf$",newUser.cash.total_amount);
    data = fopen("tmp/data.dat","a+");                                                              //open file and add later
    rec = fopen("record/rec.dat","a+");                                                             //open file and add later
    fprintf(data,"<id>%s</id> <nm>%s</nm> <dob>%s</dob> <ag>%d</ag> <nid>%s</nid> <ph>%s</ph> <add>%s</add> <gm>%s</gm> <ta>%c</ta> <tot>%lf</tot>\n",newUser.account_id,newUser.name,newUser.date_of_birth,newUser.age,newUser.national_id,newUser.phone_number,newUser.address,newUser.gmail,newUser.type_of_account,newUser.cash.total_amount);
    fprintf(rec,"<id>%s</id> <nm>%s</nm>\n",newUser.account_id,newUser.name);
    tranrec=fopen(transition_record,"a+");
    fprintf(tranrec,"<dep>%lf</dep>\n",newUser.cash.deposit_amount);
    close(data);
    close(rec);
    close(tranrec);                                                                                 //close file
    printf("\n\t\t\t\tPress 1: Go to Main Menu\n\t\t\t\tPress 2: Exit\n\n\n\n\n");                  //return mainmenu or not
    while(tf==0){
        ch=getch();
        if(ch=='1' || ch=='2'){
            break;
        }
    }
    clear();
    if(ch=='1')
        return 0;
    else{
        printf("\n\n\n\n\t\t\t\tExiting");
        loading(5);
        return 1;
    }
}


#endif // CREATE_H_INCLUDED
