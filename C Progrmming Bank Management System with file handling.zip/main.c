#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "Login.h"
#include "Limit_Input.h"
#include "Create.h"
#include "Update.h"
#include "Show.h"
#include "Detail.h"
#include "User_List.h"
#include "Remove_Account.h"
#include "Transition.h"

int main(){
    system("color 6F");
    int trueFalse=0;
    greet();                            //Greeting
    trueFalse=login_page();             //login Successful and get int for main menu loop
    char choice;
    while (trueFalse==0){               //main menu loop
        printf("\n\n\n\t\t\t\tMiner Banking Management System");
        printf("\n\n\n\t\t\t\t \xB1\xB1\xB1 Welcome to Main Menu \xB1\xB1\xB1");
        printf("\n\n\t\t\t\t1. Create new account");
        printf("\n\t\t\t\t2. Update information of existing account");
        printf("\n\t\t\t\t3. For transactions");
        printf("\n\t\t\t\t4. Check the details of existing account");
        printf("\n\t\t\t\t5. Removing existing account");
        printf("\n\t\t\t\t6. View customer's list");
        printf("\n\t\t\t\t7. Change Username or Password");
        printf("\n\t\t\t\t8. Exit");
        printf("\n\n\n\n\t\t\t\tEnter your choice:");
        choice=getch();
        system("cls");
        if(choice=='1'){
            trueFalse=create_account();     //return 1 and exit loop or return 0 for loop
        }else if(choice=='2'){
            trueFalse=update();
        }else if(choice=='3'){
            trueFalse=transition();
        }else if(choice=='4'){
            trueFalse=detail();
        }else if(choice=='5'){
            trueFalse==removeAcc();
        }else if(choice=='6'){
            trueFalse=userList();
        }else if(choice=='7'){
            trueFalse=changeUserPass();
        }else if(choice=='8'){
            printf("\n\n\t\t\tExiting.");
            loading(6);
            trueFalse=1;
        }
    }
    return 0;
}
