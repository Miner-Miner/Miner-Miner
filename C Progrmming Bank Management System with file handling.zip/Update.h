#ifndef UPDATE_H_INCLUDED
#define UPDATE_H_INCLUDED
#include "Data.h"
#include "Detail.h"

#define BUFF_MAX 1024

/*
    search account to update
    get all from file
    update to what we get
    update to file
*/

int update(){
    upd acc;
    Boolean tf=0;
    char ch,buff[BUFF_MAX],age[5],total[30];
    int line=0;
    FILE *data,*temp,*rec;
    while(tf==0){
        printf("\n\n\n\n\t\t\t\tPress 1: Update account via Username\n\t\t\t\tPress 2: Update account via ID\n\n\n\n\n");
        ch=getch();
        if(ch=='1'||ch=='2'){
            line=shrDet(ch);
            break;
        }
    }
    printf("\n\t\t\t\tPress any to continue");
    ch=getch();
    clear();
    data = fopen("tmp/data.dat","r");
    temp = fopen("tmp/temp.dat","w+");
    for (i;i<BUFF_MAX && fgets(buff,BUFF_MAX,data);i++){
        if(i==line){
            for(j=0,k=4;k<14;j++,k++){
                acc.account_id[j]=buff[k];
            }
            acc.account_id[j]='\0';
            for(j=0,k=24;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.name[j]=buff[k];
            }
            acc.name[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.date_of_birth[j]=buff[k];
            }
            acc.date_of_birth[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                age[j]=buff[k];
            }
            age[j]='\0';
            sscanf(age,"%d",&acc.age);
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.national_id[j]=buff[k];
            }
            acc.national_id[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.phone_number[j]=buff[k];
            }
            acc.phone_number[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.address[j]=buff[k];
            }
            acc.address[j]='\0';
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.gmail[j]=buff[k];
            }
            acc.gmail[j]='\0';
            for(j=0,k+=10;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                acc.type_of_account=buff[k];
            }
            for(j=0,k+=11;k<sizeof(buff)&&buff[k]!='<';j++,k++){
                total[j]=buff[k];
            }
            total[j]='\0';
            sscanf(total,"%lf",&acc.cash.total_amount);
            }else{
            fputs(buff,temp);
        }
    }
    printf("\n\n\n\n\t\t\t\t Press 1: Change Name\n\t\t\t\t Press 2: Change Date Of Birth\n\t\t\t\t Press 3: Change age\n\t\t\t\t Press 4: Change ID\n\t\t\t\t Press 5: Change Phone Number\n\t\t\t\t Press 6: Change Address\n\t\t\t\t Press 7: Change Gmail\n\n\n\n\n\n\n\n\n");
    while(tf==0){
        ch=getch();
        if(ch>48&&ch<56)
            break;
    }
    clear();
    if(ch=='1'){
        printf("\n\n\n\n\t\t\t\tEnter your name\n\t\t\t\t");
        for ( i=0,j=0; i < 20 ; i++ ){
            ch = getch();
            if(ch == 8){
                printf("\b \b");
                i-=2;
            }else if(ch==13){
                break;
            }else{
                printf("%c",ch);
                acc.name[i]=ch;
            }
        }
        acc.name[i] = '\0';
        clear();
    }else if(ch=='2'){
        while(tf==0){
            printf("\n\n\n\n\t\t\t\tEnter your birth date(dd/mm/yyyy): ");
            scanf("%s",&acc.date_of_birth);
            clear();
            tf = validate_dob(&acc.date_of_birth);
        }
    }else if(ch=='3'){
        while(tf==0){
            printf("\n\n\n\n\t\t\t\tEnter your age: ");
            acc.age=getIntOnly();
            clear();
            if(acc.age>17){
                break;
            }else{
                while(i){
                printf("\n\n\n\n\t\t\t\tAre you still minor?\n\t\t\t\tPress 0: Yes\n\t\t\t\tPress 1: No\n\n\n\n");
                ch = getch();
                clear();
                    if(ch=='0'){
                        printf("\n\n\n\n\t\t\t\tYour are still minor.\n\t\t\t\tYou can't open account.\n\t\t\t\tExiting to Main Menu.");
                        loading(5);
                        return 0;
                    }else if(ch=='1')
                        break;
                }
            }
        }
    }else if(ch=='4'){
        printf("\n\n\n\n\t\t\t\tEnter your id: ");
        scanf("%s",&acc.national_id);
    }else if(ch=='5'){
        while(tf==0){
            system("color 6F");
            printf("\n\n\n\n\t\t\t\tEnter your Ph.no: ");
            acc.phone_number[0]=getch();
            printf("%c",acc.phone_number[0]);
            int x=getIntOnly();
            int length = snprintf( NULL, 0, "%d", x );
            char* str = malloc( length + 1 );
            snprintf( str, length + 1, "%d", x );
            for(i=0;i<sizeof(str);i++){
                acc.phone_number[i+1]=str[i];
            }
            acc.phone_number[i+2]='\0';
            free(str);
            clear();
            tf=validate_phone(&acc.phone_number);
        }
    }else if(ch=='6'){
        printf("\n\n\n\n\t\t\t\tEnter your address: ");
        for ( i=0,j=0; i < 20 ; i++ ){
            ch = getch();
            if(ch == 8){
                printf("\b \b");
                i-=2;
            }else if(ch==13){
                break;
            }else{
                printf("%c",ch);
                acc.address[i]=ch;
            }
        }
        acc.address[i] = '\0';
        clear();
    }else if(ch=='7'){
        while(tf==0){
            system("color 6F");
            i=0;
            printf("\n\n\n\n\t\t\t\tEnter your Gmail: ");
            scanf("%s",&acc.gmail);
            clear();
            tf=validate_gmail(&acc.gmail);
        }
    }
    fclose(data);
    fclose(temp);
    data = fopen("tmp/data.dat","w+");
    temp = fopen("tmp/temp.dat","r");
    for (i=1;i<BUFF_MAX && fgets(buff,BUFF_MAX,temp);i++){
            fputs(buff,data);
    }
    fprintf(data,"<id>%s</id> <nm>%s</nm> <dob>%s</dob> <ag>%d</ag> <nid>%s</nid> <ph>%s</ph> <add>%s</add> <gm>%s</gm> <ta>%c</ta> <tot>%lf</tot>\n",acc.account_id,acc.name,acc.date_of_birth,acc.age,acc.national_id,acc.phone_number,acc.address,acc.gmail,acc.type_of_account,acc.cash.total_amount);
    fclose(data);
    fclose(temp);
    temp = fopen("tmp/temp.dat","w+");
    rec = fopen("record/rec.dat","r");
    for (i=0;i<BUFF_MAX && fgets(buff,BUFF_MAX,rec);i++){
        if(i!=line){
            fputs(buff,temp);
        }
    }
    fclose(rec);
    fclose(temp);
    temp = fopen("tmp/temp.dat","r");
    rec = fopen("record/rec.dat","w+");
    for (i=0;i<BUFF_MAX && fgets(buff,BUFF_MAX,temp);i++){
        fputs(buff,rec);
    }
    fprintf(rec,"<id>%s</id> <nm>%s</nm>\n",acc.account_id,acc.name);
    fclose(rec);
    fclose(temp);
    printf("\n\n\n\n\t\t\t\tUpdating");
    loading(5);
    printf("\n\n\n\n\t\t\t\tUpdated");
    printf("\n\n\t\t\t\tAccount Id           : %s",acc.account_id);
    printf("\n\t\t\t\tName                 : %s",acc.name);
    printf("\n\t\t\t\tDate of Birth        : %s",acc.date_of_birth);
    printf("\n\t\t\t\tAge                  : %d",acc.age);
    printf("\n\t\t\t\tID                   : %s",acc.national_id);
    printf("\n\t\t\t\tPhone Number         : %s",acc.phone_number);
    printf("\n\t\t\t\tAddress              : %s",acc.address);
    printf("\n\t\t\t\tGmail                : %s",acc.gmail);
    printf("\n\t\t\t\tType of Account      : %c->",acc.type_of_account);
    type(acc.type_of_account);
    printf("\n\t\t\t\tTotla Amount         : %lf$",acc.cash.total_amount);
    printf("\n\t\t\t\tPress 1: Back to Main Menu\n\t\t\t\tPress 2: Exit");
    while(1){
        ch=getch();
        if(ch=='1'){
            clear();
            printf("\n\n\n\n\t\t\t\tReturning to Main Menu");
            loading(5);            return 0;
        }else if(ch=='2'){
            clear();
            printf("\n\n\n\n\t\t\t\tExiting");
            loading(5);
            return 1;
        }
    }
}

#endif // UPDATE_H_INCLUDED
