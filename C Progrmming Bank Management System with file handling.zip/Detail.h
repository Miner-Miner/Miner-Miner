#ifndef DETAIL_H_INCLUDED
#define DETAIL_H_INCLUDED
#define BUFF_MAX 1024

int shrDet(char c){
    det acc;
    int i=0,j=0,k,trueFalse=0,line=0,lineCpy[BUFF_MAX];
    char ch,tmpName[30],tmpID[30],buff[BUFF_MAX],any[BUFF_MAX];
    FILE *rec;
    rec = fopen("record/rec.dat","r");                                      //open file
    while(trueFalse==0){
        ch=c;                                                               //get by using name or id
        clear();
        if(ch=='1'){
            printf("\n\n\n\n\t\t\t\tEnter Username\n\t\t\t\t");             //search by name if the account exists
            for ( i=0,j=0; i < 20 ; i++ ){
                ch = getch();
                if(ch == 8){
                    printf("\b \b");
                    i-=2;
                }else if(ch==13){
                    break;
                }else{
                    printf("%c",ch);
                    any[i]=ch;
                }
            }
            any[i] = '\0';
            clear();
            printf("\n\n\n");
            for(i=0;i<BUFF_MAX&&fgets(buff,BUFF_MAX,rec)!=NULL;i++){
                for( k=0,j=20;j<sizeof(buff)&&buff[j]!='\0';j++,k++){
                    ch=buff[j];
                    tmpName[k]=ch;
                }
                tmpName[k]=0;
                for( k=0,j=4;j<14;j++,k++){
                    ch=buff[j];
                    tmpID[k]=ch;
                }
                tmpID[k]='\0';
                for(k=0,j=4;j<sizeof(tmpName)&&tmpName[j]!=NULL;j++,k++){
                    if(tmpName[j]!='<'){
                        tmpName[k]=tmpName[j];
                    }else{
                        j=sizeof(tmpName);
                    }
                }
                tmpName[k-1]='\0';
                if(strcmp(tmpName,any)==0){                                                             //if account exist print this
                    lineCpy[line]=i;
                    printf("\n\t\t\t\tPress %d: Account Id: %s Name: %s",line,tmpID,tmpName);
                    line++;
                }
            }
            printf("\n\n\n\n");
            if(line==0){                                                                                //if not print this
                printf("\t\t\t\tThere is no Account Name that is %s.",any);
                delay(900000000);
                clear();
                shrDet('1');
            }else{
                int num;
                while(1){
                    num=getch();
                    num=num-48;
                    if(num<(line)){
                        break;
                    }
                }
                clear();
                show(lineCpy[num]);
                printf("\n\n\n");
                return lineCpy[num];                                                                //return line number
            }
        }else if(ch=='2'){
            clear();
            printf("\n\n\n\t\t\t\tEnter ID\n\t\t\t\t");                                             //search by id
            for ( i=0,j=0; i < 20 ; i++ ){
                ch = getch();
                if(ch>=48 && ch<=57){
                    any[i]=ch;
                    printf("%c",ch);
                }else if(ch == 8){
                    clear();
                    printf("\n\n\n\t\t\t\tEnter ID\n\t\t\t\t");
                    for(j=0;j<i-1;j++){
                        printf("%c",acc.account_id[j]);
                    }
                    i-=2;
                }else if(ch==13)
                    break;
                }
            acc.account_id[10] = '\0';
            clear();
            for(i=0;i<BUFF_MAX&&fgets(buff,BUFF_MAX,rec)!=NULL;i++){
                for( k=0,j=4;j<14;j++,k++){
                    ch=buff[j];
                    tmpID[k]=ch;
                }
                tmpID[10]=='\0';
                if(strcmp(tmpID,any)==0){                                                           //if account exists break from loop and return i
                    line++;
                    break;
                }
            }
            if(line==0){
                printf("\n\n\n\n\t\t\t\tThere is no Account ID that is %s.",any);                   //if not print this and try again
                delay(900000000);
                clear();
                shrDet('2');
            }
            show(i);
            return i;
        }
    }
    fclose(rec);
}

int detail(){
    char ch;
    while(1){
        printf("\n\n\n\n\t\t\t\tPress 1: Check account via Username\n\t\t\t\tPress 2: Check account via ID\n\n\n\n\n");
        ch=getch();
        if(ch=='1'||ch=='2'){
            shrDet(ch);
        }
    }
    printf("\n\n\n\n\t\t\t\tPress 1: Goto Main Menu\n\t\t\t\tPress 2: Exit");
    while(1){
        ch=getch();
        if(ch=='1'){
            clear();
            printf("\n\n\n\n\t\t\t\tReturning to Main Menu");
            loading(5);
            clear();
            return 0;
        }else if(ch=='2'){
            clear();
            printf("\n\n\n\n\t\t\t\tExiting");
            loading(5);            clear();
            return 1;
        }
    }
}


#endif // DETAIL_H_INCLUDED
